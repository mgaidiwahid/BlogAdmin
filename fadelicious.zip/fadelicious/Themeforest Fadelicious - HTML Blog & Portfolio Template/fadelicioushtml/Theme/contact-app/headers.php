<?php
session_start(); // Start Session
header('Cache-control: private'); // IE 6 FIX
?>