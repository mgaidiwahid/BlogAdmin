


$(document).ready(function(){
var Duration = 250; //time in milliseconds

	      $('.ddsmoothmenu ul li ul li').hover(function() {
	        $(this).animate({ paddingLeft: '10px' }, Duration);
	      }, function() {
	        $(this).animate({ paddingLeft: '0px' }, Duration);           
	      });

		
});

$(document).ready(function(){
var Duration = 250; //time in milliseconds

	      $('.list-wrap li').hover(function() {
	        $(this).animate({ paddingLeft: '30px' }, Duration);
	      }, function() {
	        $(this).animate({ paddingLeft: '20px' }, Duration);           
	      });

		
});

$(document).ready(function(){
var Duration = 250; //time in milliseconds

	      $('.list li').hover(function() {
	        $(this).animate({ paddingLeft: '30px' }, Duration);
	      }, function() {
	        $(this).animate({ paddingLeft: '20px' }, Duration);           
	      });

		
});